﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace ReceiverApp
{
    public partial class MainWindow : Window
    {
        private Thread listenerThread;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartListeningButton_Click(object sender, RoutedEventArgs e)
        {
            listenerThread = new Thread(StartListening);
            listenerThread.IsBackground = true;
            listenerThread.Start();
            MessageBox.Show("Listening for messages...");
        }

        private void StartListening()
        {
            TcpListener listener = new TcpListener(IPAddress.Any, 5000);
            listener.Start();

            while (true)
            {
                try
                {
                    using (TcpClient client = listener.AcceptTcpClient())
                    {
                        NetworkStream stream = client.GetStream();
                        byte[] buffer = new byte[1024];
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                        Dispatcher.Invoke(() =>
                        {
                            ReceivedTextBlock.Text = $"Received: {receivedMessage}";
                        });
                    }
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        MessageBox.Show($"Error: {ex.Message}");
                    });
                }
            }
        }
    }
}
