﻿using System;
using System.Windows;

namespace WpfModbusClient
{
    public partial class CommSettingsWindow : Window
    {
        // 설정값을 담을 프로퍼티들
        public string BizCode { get; set; }      // 사업장 코드
        public string StackCode { get; set; }    // 굴뚝 코드
        public string GatewayIP { get; set; }    // 게이트웨이 IP
        public int GatewayPort { get; set; }     // 게이트웨이 포트
        public int ServerPort { get; set; }      // 통신서버 포트

        public CommSettingsWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // 기존 값을 UI에 표시
            txtBizCode.Text = BizCode;
            txtStackCode.Text = StackCode;
            txtGatewayIP.Text = GatewayIP;
            txtGatewayPort.Text = GatewayPort.ToString();
            txtServerPort.Text = ServerPort.ToString();
        }

        private void btnOK_Click(object sender, RoutedEventArgs e)
        {
            // UI에서 값 읽어오기
            BizCode = txtBizCode.Text.Trim();
            StackCode = txtStackCode.Text.Trim();
            GatewayIP = txtGatewayIP.Text.Trim();

            int gwPort, svrPort;
            if (!int.TryParse(txtGatewayPort.Text.Trim(), out gwPort)) gwPort = 9090;
            if (!int.TryParse(txtServerPort.Text.Trim(), out svrPort)) svrPort = 5010;

            GatewayPort = gwPort;
            ServerPort = svrPort;

            this.DialogResult = true; // OK
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false; // 취소
        }
    }
}
