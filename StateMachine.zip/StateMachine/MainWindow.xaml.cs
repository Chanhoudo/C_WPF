﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.IO;
using System.Windows.Controls;
using static WpfModbusClient.MainWindow;

namespace WpfModbusClient
{

    public partial class MainWindow : Window
    {
        public enum SensorStatus
        {
            Normal,                // 정상 (0)
            OutOfRange,            // 비정상범위 (1)
            CommunicationFailure,  // 통신불량 (2)
            PowerFailure,          // 전원단절 (4)
            Maintenance            // 점검중 (8)
        }
        public class SensorData
        {
            public DateTime Timestamp { get; set; }
            public double Measurement { get; set; }
            public SensorStatus Status { get; set; }
        }
        public enum OperatingStatus 
        { Stopped, Running }
        public class FiveMinuteData
        {
            public DateTime Timestamp { get; set; }
            public double Measurement { get; set; }
            public SensorStatus Status { get; set; }
            public OperatingStatus OperatingStatus { get; set; }
        }
        public class ThirtyMinuteData
        {
            public DateTime Timestamp { get; set; }
            public double Measurement { get; set; }
            public SensorStatus Status { get; set; }
            public OperatingStatus OperatingStatus { get; set; }
        }
        public class FiveSecondData
        {
            public DateTime Timestamp { get; set; }
            public double Measurement { get; set; }
            public SensorStatus Status { get; set; }
        }


        public static readonly ushort[] CRC_TABLE = new ushort[256]
        {
            0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
            0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
            0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
            0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
            0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
            0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
            0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
            0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
            0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
            0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
            0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
            0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
            0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
            0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
            0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
            0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
            0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
            0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
            0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
            0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
            0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
            0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
            0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
            0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
            0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
            0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
            0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
            0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
            0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
            0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
            0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
            0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
            // (전체 256개 값을 정확히 채워야 함)
        };

        // 기존 통신 설정값 (CommSettingsWindow에서 설정)
        private string _bizCode = "4100535";
        private string _stackCode = "001";
        private string _gatewayIP = "192.168.100.3";  // WPF 앱(서버) IP
        private int _gatewayPort = 9090;              // 게이트웨이 접속용 포트 (예: 명령 수신용)
        private int _commServerPort = 5010;           // 추가 통신서버 포트 (용도에 따라 사용)

        // Arduino 관련 변수
        private TcpClient _client;
        private NetworkStream _stream;
        private System.Threading.Timer _autoSendTimer;

        // 서버 Gateway 관련 변수 (일반 데이터 수신)
        private TcpClient _serverGatewayClient;
        private NetworkStream _serverGatewayStream;
        private CancellationTokenSource _serverReceiveCts; // 연속 수신 취소 토큰

        // 새로 추가: 게이트웨이 명령 수신용 리스너 (상시 오픈)
        private TcpListener _commandListener;
        private CancellationTokenSource _commandListenerCts;

        // 센서 정보 모니터링
        private SensorMonitor sensorMonitor;
        public MainWindow()
        {
            InitializeComponent();
            sensorMonitor = new SensorMonitor(this);
            // 애플리케이션 시작 시 게이트웨이 명령 리스너 시작
            StartGatewayCommandListener();
        }

        public class SensorMonitor
        {
            private MainWindow _mainWindow;  // ✅ MainWindow 참조 추가
            private Dictionary<int, List<FiveSecondData>> fiveSecondData = new Dictionary<int, List<FiveSecondData>>();
            private Dictionary<int, List<FiveMinuteData>> fiveMinuteData = new Dictionary<int, List<FiveMinuteData>>();
            private Dictionary<int, List<ThirtyMinuteData>> thirtyMinuteData = new Dictionary<int, List<ThirtyMinuteData>>();
            public List<FiveSecondData> GetFiveSecondData()
            {
                return fiveSecondData.SelectMany(kv => kv.Value).ToList();
            }

            public List<FiveMinuteData> GetFiveMinuteData()
            {
                return fiveMinuteData.SelectMany(kv => kv.Value).ToList();
            }

            public List<ThirtyMinuteData> GetThirtyMinuteData()
            {
                return thirtyMinuteData.SelectMany(kv => kv.Value).ToList();
            }


            private Timer fiveSecondTimer;  // 5초 실행
            private Timer fiveMinuteTimer;  // 5분 실행

            private object lockObj = new object();  //동시 접근 방지

            public SensorMonitor(MainWindow mainWindow)
            {
                _mainWindow = mainWindow;
                //Start
                // 1~4번 센서 데이터 리스트 초기화
                for (int i = 1; i <= 4; i++)
                {
                    fiveSecondData[i] = new List<FiveSecondData>();
                    fiveMinuteData[i] = new List<FiveMinuteData>();
                    thirtyMinuteData[i] = new List<ThirtyMinuteData>();
                }
            }

            public void StartMonitoring()
            {
                AddLog("[DEBUG] 센서 모니터링 시작됨");

                fiveSecondTimer = new Timer(_ =>
                {
                    AddLog("[DEBUG] 5초 타이머 실행됨");
                    GenerateFiveSecondData();
                }, null, TimeSpan.Zero, TimeSpan.FromSeconds(5));

                // 5분 타이머 실행
                TimeSpan timeToNext5Min = TimeSpan.FromMinutes(5) - TimeSpan.FromMinutes(DateTime.Now.Minute % 5)
                                          - TimeSpan.FromSeconds(DateTime.Now.Second);
                fiveMinuteTimer = new Timer(_ =>
                {
                    AddLog("[DEBUG] 5분 타이머 실행됨");
                    GenerateFiveMinuteData();
                }, null, timeToNext5Min, TimeSpan.FromMinutes(5));
            }


            public void StopMonitoring()
            {
                fiveSecondTimer?.Dispose();
                fiveMinuteTimer?.Dispose();
            }

            public void AddSensorData(int sensorId, double measurement)
            {
                lock (lockObj)
                {
                    SensorStatus status = (measurement >= 5) ? SensorStatus.Normal : SensorStatus.PowerFailure;

                    fiveSecondData[sensorId].Add(new FiveSecondData
                    {
                        Timestamp = DateTime.Now,
                        Measurement = measurement,
                        Status = status
                    });

                    AddLog($"[센서 {sensorId} 데이터 추가] {DateTime.Now:HH:mm:ss} | 값: {measurement}, 상태: {status}");
                    _mainWindow.UpdateSensorData();  // ✅ 데이터 추가 후 UI 업데이트 호출
                }
            }


            private void GenerateFiveSecondData()
            {
                lock (lockObj)
                {
                    DateTime now = DateTime.Now;

                    for (int sensorId = 1; sensorId <= 4; sensorId++)
                    {
                        if (fiveSecondData[sensorId].Count == 0) continue;

                        var mostFrequentMeasurement = fiveSecondData[sensorId]
                            .GroupBy(d => d.Measurement)
                            .OrderByDescending(g => g.Count())
                            .First().Key;

                        fiveSecondData[sensorId].Clear();

                        AddLog($"[5초 데이터] 센서 {sensorId} | {now:HH:mm:ss} | 최빈값: {mostFrequentMeasurement}");
                    }
                }
            }

            private void GenerateFiveMinuteData()
            {
                lock (lockObj)
                {
                    DateTime now = DateTime.Now;
                    DateTime startTime = now.AddMinutes(-5);

                    for (int sensorId = 1; sensorId <= 4; sensorId++)
                    {
                        var recentData = fiveSecondData[sensorId].Where(d => d.Timestamp >= startTime).ToList();
                        if (recentData.Count == 0) continue;

                        var normalData = recentData.Where(d => d.Status == SensorStatus.Normal).ToList();
                        double avgValue = (normalData.Count >= recentData.Count / 2)
                            ? normalData.Average(d => d.Measurement)
                            : recentData.Average(d => d.Measurement);

                        SensorStatus finalStatus = DetermineFinalStatus(
                            recentData.Select(d => new SensorData { Status = d.Status }).ToList()
                        );
                        OperatingStatus finalOperatingStatus = (avgValue >= 5) ? OperatingStatus.Running : OperatingStatus.Stopped;

                        fiveMinuteData[sensorId].Add(new FiveMinuteData
                        {
                            Timestamp = now,
                            Measurement = avgValue,
                            Status = finalStatus,
                            OperatingStatus = finalOperatingStatus
                        });

                        AddLog($"[5분 데이터] 센서 {sensorId} | {now:HH:mm} | 평균값: {avgValue}, 상태: {finalStatus}, 가동상태: {finalOperatingStatus}");
                    }

                    // 30분 단위일 때 30분 데이터 생성
                    if (now.Minute % 30 == 0)
                    {
                        GenerateThirtyMinuteData();
                    }
                }
            }

            private void GenerateThirtyMinuteData()
            {
                lock (lockObj)
                {
                    DateTime now = DateTime.Now;
                    DateTime startTime = now.AddMinutes(-30);

                    for (int sensorId = 1; sensorId <= 4; sensorId++)
                    {
                        var recentData = fiveMinuteData[sensorId].Where(d => d.Timestamp >= startTime).ToList();
                        if (recentData.Count == 0) continue;

                        double avgValue = recentData.Average(d => d.Measurement);
                        SensorStatus finalStatus = DetermineFinalStatus(
                            recentData.Select(d => new SensorData { Status = d.Status }).ToList()
                        );
                        OperatingStatus finalOperatingStatus = (avgValue >= 5) ? OperatingStatus.Running : OperatingStatus.Stopped;

                        thirtyMinuteData[sensorId].Add(new ThirtyMinuteData
                        {
                            Timestamp = now,
                            Measurement = avgValue,
                            Status = finalStatus,
                            OperatingStatus = finalOperatingStatus
                        });

                        AddLog($"[30분 데이터] 센서 {sensorId} | {now:HH:mm} | 평균값: {avgValue}, 상태: {finalStatus}, 가동상태: {finalOperatingStatus}");
                    }

                    SaveThirtyMinuteDataToFile();
                }
            }



            // ✅ 30분 데이터 저장 기능
            private void SaveThirtyMinuteDataToFile()
            {
                foreach (var sensorId in thirtyMinuteData.Keys) // 각 센서별 저장
                {
                    string filePath = $"SensorData_Sensor{sensorId}_{DateTime.Now:yyyyMMdd_HHmm}.txt";
                    StringBuilder sb = new StringBuilder();

                    sb.AppendLine($"📌 [30분 데이터 저장 - 센서 {sensorId}]");
                    foreach (var data in thirtyMinuteData[sensorId])
                    {
                        sb.AppendLine($"🕒 {data.Timestamp:HH:mm} | 📊 값: {data.Measurement} | 상태: {data.Status} | 가동상태: {data.OperatingStatus}");
                    }

                    File.WriteAllText(filePath, sb.ToString());
                    Console.WriteLine($"✅ 30분 데이터가 저장되었습니다: {filePath}");
                }
            }


            // ✅ 데이터 보기 기능 추가
            public void ShowDataPopup()
            {
                StringBuilder sb = new StringBuilder();

                // ✅ [5분 데이터] 센서별로 출력
                sb.AppendLine("📌 [5분 데이터]");
                foreach (var sensorId in fiveMinuteData.Keys)
                {
                    sb.AppendLine($"--- 센서 {sensorId} ---");
                    foreach (var data in fiveMinuteData[sensorId])
                    {
                        sb.AppendLine($"🕒 {data.Timestamp:HH:mm} | 📊 값: {data.Measurement} | 상태: {data.Status} | 가동상태: {data.OperatingStatus}");
                    }
                    sb.AppendLine(); // 센서별 개행 추가
                }

                // ✅ [30분 데이터] 센서별로 출력
                sb.AppendLine("\n📌 [30분 데이터]");
                foreach (var sensorId in thirtyMinuteData.Keys)
                {
                    sb.AppendLine($"--- 센서 {sensorId} ---");
                    foreach (var data in thirtyMinuteData[sensorId])
                    {
                        sb.AppendLine($"🕒 {data.Timestamp:HH:mm} | 📊 값: {data.Measurement} | 상태: {data.Status} | 가동상태: {data.OperatingStatus}");
                    }
                    sb.AppendLine(); // 센서별 개행 추가
                }

                MessageBox.Show(sb.ToString(), "데이터 모니터링", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            private SensorStatus DetermineFinalStatus(List<SensorData> dataList)
            {
                if (dataList == null || dataList.Count == 0)
                    return SensorStatus.Normal; // 기본값 정상

                // 비정상 상태 우선순위 적용 (점검중 > 전원단절 > 통신불량 > 비정상범위 > 정상)
                if (dataList.Any(d => d.Status == SensorStatus.Maintenance))
                    return SensorStatus.Maintenance;
                if (dataList.Any(d => d.Status == SensorStatus.PowerFailure))
                    return SensorStatus.PowerFailure;
                if (dataList.Any(d => d.Status == SensorStatus.CommunicationFailure))
                    return SensorStatus.CommunicationFailure;
                if (dataList.Any(d => d.Status == SensorStatus.OutOfRange))
                    return SensorStatus.OutOfRange;

                return SensorStatus.Normal;
            }

        }
        // 모니터링 시작 버튼
        private void btnStartMonitoring_Click(object sender, RoutedEventArgs e)
        {
            sensorMonitor.StartMonitoring();
            AddLog("Sensor monitoring started.");
        }
        // 모니터링 중지 버튼
        private void btnStopMonitoring_Click(object sender, RoutedEventArgs e)
        {
            sensorMonitor.StopMonitoring();
            AddLog("Sensor monitoring stopped.");
        }
        // ✅ UI 업데이트 메서드
        public void UpdateSensorData()
        {
            Dispatcher.Invoke(() =>
            {
                listFiveSecondData.ItemsSource = null;
                listFiveSecondData.ItemsSource = sensorMonitor.GetFiveSecondData();  // ✅ 센서 모니터에서 가져옴

                listFiveMinuteData.ItemsSource = null;
                listFiveMinuteData.ItemsSource = sensorMonitor.GetFiveMinuteData();  // ✅ 센서 모니터에서 가져옴

                listThirtyMinuteData.ItemsSource = null;
                listThirtyMinuteData.ItemsSource = sensorMonitor.GetThirtyMinuteData();  // ✅ 센서 모니터에서 가져옴
            });
        }





        #region 통신 설정 연동
        private void btnCommSettings_Click(object sender, RoutedEventArgs e)
        {
            var settingsWin = new CommSettingsWindow()
            {
                Owner = this,
                BizCode = _bizCode,
                StackCode = _stackCode,
                GatewayIP = _gatewayIP,
                GatewayPort = _gatewayPort,
                ServerPort = _commServerPort
            };

            bool? result = settingsWin.ShowDialog();
            if (result == true)
            {
                _bizCode = settingsWin.BizCode;
                _stackCode = settingsWin.StackCode;
                _gatewayIP = settingsWin.GatewayIP;
                _gatewayPort = settingsWin.GatewayPort;
                _commServerPort = settingsWin.ServerPort;

                AddLog($"[통신설정] 사업장:{_bizCode}, 굴뚝:{_stackCode}, GW IP:{_gatewayIP}:{_gatewayPort}, ServerPort:{_commServerPort}");
            }
            else
            {
                AddLog("[통신설정] 취소됨");
            }
        }
        #endregion


        #region Arduino 연결/전송 (기존 코드)
        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ip = txtIP.Text.Trim();
                int port = int.Parse(txtPort.Text.Trim());

                _client = new TcpClient(ip, port);
                _stream = _client.GetStream();
                AddLog($"Connected to Arduino at {ip}:{port}");

                _autoSendTimer = new System.Threading.Timer(AutoSendRequestCallback, null, 0, 1000);
            }
            catch (Exception ex)
            {
                AddLog($"Arduino Connection error: {ex.Message}");
            }
        }

        private void btnDisconnect_Click(object sender, RoutedEventArgs e)
        {
            DisconnectFromArduino();
        }

        private void DisconnectFromArduino()
        {
            try
            {
                _autoSendTimer?.Dispose();
                _autoSendTimer = null;

                _stream?.Close();
                _stream = null;

                _client?.Close();
                _client = null;

                AddLog("Disconnected from Arduino.");
            }
            catch (Exception ex)
            {
                AddLog($"Arduino Disconnect error: {ex.Message}");
            }
        }

        private async void btnSendRequest_Click(object sender, RoutedEventArgs e)
        {
            await SendRequestAsync();
        }

        private async void AutoSendRequestCallback(object state)
        {
            if (_stream == null || !_client.Connected)
                return;
            await SendRequestAsync(autoMode: true);
        }

        private async Task SendRequestAsync(bool autoMode = false)
        {
            try
            {
                byte[] request = new byte[12];
                request[0] = 0x42;  // 'B'
                request[1] = 0x44;  // 'D'
                request[2] = 0x00;
                request[3] = 0x08;
                request[4] = 0x00;
                request[5] = 0x01;
                request[6] = 0x01;
                request[7] = 0x03;
                request[8] = 0x00;
                request[9] = 0x00;
                request[10] = 0x00;
                request[11] = 0x04;

                await _stream.WriteAsync(request, 0, request.Length);
                AddLog("[DEBUG] Arduino Request sent.");

                byte[] buffer = new byte[256];
                int bytesRead = await _stream.ReadAsync(buffer, 0, buffer.Length);
                AddLog($"[DEBUG] Arduino: Received {bytesRead} bytes.");

                if (bytesRead == 0)
                {
                    AddLog("[ERROR] Arduino: No response received!");
                    return;
                }

                string hex = BitConverter.ToString(buffer, 0, bytesRead);
                AddLog($"[DEBUG] Arduino: Response HEX: {hex}");

                if (bytesRead < 9)
                {
                    AddLog("[ERROR] Arduino: Received data is too short.");
                    return;
                }

                int byteCount = buffer[8];
                AddLog($"[DEBUG] Expected sensor data length: {byteCount}");

                if (bytesRead < 9 + byteCount)
                {
                    AddLog("[ERROR] Arduino: Received data length is less than expected.");
                    return;
                }

                byte[] sensorData = new byte[byteCount];
                Array.Copy(buffer, 9, sensorData, 0, byteCount);
                AddLog($"[DEBUG] Arduino Sensor Data (raw): {BitConverter.ToString(sensorData)}");

                

                // ✅ UI 업데이트
                UpdateSensorData(sensorData);

            }
            catch (Exception ex)
            {
                AddLog($"[ERROR] Arduino Exception: {ex.Message}");
            }
        }


        private void UpdateSensorData(byte[] sensorData)
        {
            if (sensorData.Length < 8)
            {
                AddLog("Arduino: Insufficient sensor data length.");
                return;
            }

            double m = 49.89 / (65366 - 13114.0);
            double b = 0.11 - m * 13114;

            int rawCurrent1 = (sensorData[0] << 8) | sensorData[1];
            int rawCurrent2 = (sensorData[2] << 8) | sensorData[3];
            int rawCurrent3 = (sensorData[4] << 8) | sensorData[5];
            int rawCurrent4 = (sensorData[6] << 8) | sensorData[7];

            double current1 = m * rawCurrent1 + b;
            double current2 = m * rawCurrent2 + b;
            double current3 = m * rawCurrent3 + b;
            double current4 = m * rawCurrent4 + b;

            Dispatcher.Invoke(() =>
            {
                txtCurrent1.Text = current1.ToString("F2") + " A";
                txtCurrent2.Text = current2.ToString("F2") + " A";
                txtCurrent3.Text = current3.ToString("F2") + " A";
                txtCurrent4.Text = current4.ToString("F2") + " A";
            });

            // ✅ 센서 데이터 추가 (여기 추가됨!)
            sensorMonitor.AddSensorData(1, current1);
            sensorMonitor.AddSensorData(2, current2);
            sensorMonitor.AddSensorData(3, current3);
            sensorMonitor.AddSensorData(4, current4);

            AddLog($"Arduino Updated Currents - 1: {current1:F2} A, 2: {current2:F2} A, 3: {current3:F2} A, 4: {current4:F2} A");
        }
        #endregion


        #region 서버 Gateway 연결/데이터 수신
        private void btnConnectServer_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // UI에 입력된 값을 사용 (또는 설정값을 활용 가능)
                string ip = txtServerIP.Text.Trim();
                int port = int.Parse(txtServerPort.Text.Trim());

                _serverGatewayClient = new TcpClient(ip, port);
                _serverGatewayStream = _serverGatewayClient.GetStream();
                AddLog($"Connected to Server Gateway at {ip}:{port}");

                _serverReceiveCts = new CancellationTokenSource();
                StartServerReceiveLoop(_serverReceiveCts.Token);
            }
            catch (Exception ex)
            {
                AddLog($"Server Gateway Connection error: {ex.Message}");
            }
        }

        private void btnDisconnectServer_Click(object sender, RoutedEventArgs e)
        {
            DisconnectFromServerGateway();
        }

        private void DisconnectFromServerGateway()
        {
            try
            {
                _serverReceiveCts?.Cancel();
                _serverReceiveCts = null;

                _serverGatewayStream?.Close();
                _serverGatewayStream = null;

                _serverGatewayClient?.Close();
                _serverGatewayClient = null;

                AddLog("Disconnected from Server Gateway.");
            }
            catch (Exception ex)
            {
                AddLog($"Server Gateway Disconnect error: {ex.Message}");
            }
        }

        private void StartServerReceiveLoop(CancellationToken token)
        {
            Task.Run(async () =>
            {
                byte[] buffer = new byte[256];
                while (!token.IsCancellationRequested && _serverGatewayClient != null && _serverGatewayClient.Connected)
                {
                    try
                    {
                        int bytesRead = await _serverGatewayStream.ReadAsync(buffer, 0, buffer.Length, token);
                        if (bytesRead > 0)
                        {
                            string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                            AddLog($"Server Gateway Data: {data}");
                            // 필요한 경우 데이터 파싱 후 UI 업데이트 등
                        }
                        else
                        {
                            AddLog("Server Gateway: Connection closed by remote.");
                            break;
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        AddLog("Server Gateway receive loop canceled.");
                        break;
                    }
                    catch (Exception ex)
                    {
                        AddLog($"Error receiving from Server Gateway: {ex.Message}");
                        break;
                    }
                }
                AddLog("Server Gateway receive loop ended.");
            }, token);
        }
        #endregion

        #region 게이트웨이 명령 리스너 (Command Listener)
        // 192.168.100.3:9090에서 게이트웨이의 명령 접속을 기다림
        private void StartGatewayCommandListener()
        {
            try
            {
                // 서버 IP는 192.168.100.3 (WPF 앱의 IP)로 고정
                IPAddress localAddr = IPAddress.Parse("192.168.100.3");
                _commandListener = new TcpListener(localAddr, 9090);
                _commandListener.Start();
                AddLog("Gateway Command Listener started on 192.168.100.3:9090");

                _commandListenerCts = new CancellationTokenSource();
                Task.Run(() => AcceptGatewayCommandConnections(_commandListenerCts.Token));
            }
            catch (Exception ex)
            {
                AddLog("Error starting Gateway Command Listener: " + ex.Message);
            }
        }

        private async Task AcceptGatewayCommandConnections(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    TcpClient client = await _commandListener.AcceptTcpClientAsync();
                    AddLog("Gateway connected for command.");

                    // 연결 수락 후, 즉시 "OK" 응답 전송
                    NetworkStream ns = client.GetStream();
                    //byte[] okResponse = Encoding.ASCII.GetBytes("OK");
                    //await ns.WriteAsync(okResponse, 0, okResponse.Length, token);
                    AddLog("Sent OK to Gateway.");

                    // 연결된 클라이언트에 대해 별도 Task로 명령 수신 처리
                    _ = Task.Run(() => HandleGatewayCommandClient(client, token), token);
                }
                catch (Exception ex)
                {
                    AddLog("Error accepting command connection: " + ex.Message);
                }
            }
            AddLog("Gateway Command Listener stopped.");
        }

        private async Task HandleGatewayCommandClient(TcpClient client, CancellationToken token)
        {
            try
            {
                NetworkStream ns = client.GetStream();
                byte[] buffer = new byte[256];  // 크기를 너무 크게 안 해도 됨
                StringBuilder receivedData = new StringBuilder();

                while (!token.IsCancellationRequested && client.Connected)
                {
                    int bytesRead = await ns.ReadAsync(buffer, 0, buffer.Length, token);
                    if (bytesRead == 0)
                        break; // 연결 종료

                    // 1) 수신 데이터를 문자열(ASCII)로 변환
                    string rawData = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    receivedData.Append(rawData);
                    AddLog($"Received Raw Data: {rawData}");

                    // ✅ **ACK / NAK / EOT 확인 (추가된 부분)**
                    if (bytesRead == 1)  // 1바이트 응답만 오는 경우
                    {
                        byte responseCode = buffer[0];

                        if (responseCode == 0x06)  // ACK
                        {
                            AddLog("[SUCCESS] Server Acknowledgment (ACK 0x06) received!");

                            // ✅ **EOT(0x04) 전송 후 연결 종료**
                            await SendEOT(ns);
                            break;
                        }
                        else if (responseCode == 0x15)  // NAK
                        {
                            AddLog("[WARNING] Server Negative Acknowledgment (NAK 0x15) received!");
                            receivedData.Clear();
                            continue;
                        }
                        else if (responseCode == 0x04)  // EOT (서버가 보낸 경우)
                        {
                            AddLog("[INFO] Server End of Transmission (EOT 0x04) received.");
                            receivedData.Clear();
                            break;
                        }
                    }

                    // 2) `<ACK>`를 확인 (길이가 짧아도 감지할 수 있도록)
                    if (receivedData.ToString().Contains("<ACK>"))
                    {
                        AddLog("[SUCCESS] Server Acknowledgment (<ACK>) received!");

                        // ✅ **EOT(0x04) 전송 후 연결 종료**
                        await SendEOT(ns);
                        break;
                    }

                    // 3) 최소 4바이트 이상인지 확인
                    if (receivedData.Length < 4)
                    {
                        AddLog("Invalid command (less than 4 chars).");
                        continue;
                    }

                    // 4) 명령어 파싱 (앞 4글자)
                    string commandCode = receivedData.ToString().Substring(0, 4);
                    AddLog("Command Code: " + commandCode);

                    // 5) CRC 검증 (예: 마지막 4바이트가 CRC라면...)
                    if (receivedData.Length >= 6)
                    {
                        string possibleCrc = receivedData.ToString().Substring(receivedData.Length - 6);
                        AddLog("Possible CRC segment: " + possibleCrc);
                    }

                    // 6) 명령어별 처리
                    switch (commandCode)
                    {
                        case "PDUH":
                            HandlePDUH(receivedData.ToString());
                            break;
                        case "PCNG":
                            HandlePCNG(receivedData.ToString());
                            break;
                        case "PCN2":
                            await HandlePCN2(receivedData.ToString(), ns);
                            break;
                        default:
                            AddLog("Unknown command: " + commandCode);
                            break;
                    }

                    // 모든 데이터 처리 후 버퍼 초기화
                    receivedData.Clear();
                }
            }
            catch (OperationCanceledException)
            {
                AddLog("Command handling canceled.");
            }
            catch (Exception ex)
            {
                AddLog("Error in command handling: " + ex.Message);
            }
            finally
            {
                client.Close();
                AddLog("Command connection closed.");
            }
        }

        // ✅ **EOT(0x04)를 전송하는 함수 추가**
        private async Task SendEOT(NetworkStream ns)
        {
            try
            {
                byte[] eotMessage = new byte[] { 0x04 }; // EOT (0x04)
                await ns.WriteAsync(eotMessage, 0, eotMessage.Length);
                AddLog("[INFO] Sent End of Transmission (EOT 0x04) to server.");
            }
            catch (Exception ex)
            {
                AddLog($"[ERROR] Failed to send EOT: {ex.Message}");
            }
        }

        // 예시: PDUH 처리
        private void HandlePDUH(string rawData)
        {
            // rawData 예: "PDUH4100535001 43FIV25022413502502241450<4F><4B>"
            // 1) PDUH(4) + 사업장코드(7) + 굴뚝코드(3) + ...
            // 2) 중간 공백이나 구분자 파악
            // 3) 자료구분(FIV/HAF/ALL), 날짜시간(YYMMDDhhmm 등) 파싱
            AddLog("[PDUH] Handling: " + rawData);
            // 필요한 로직 수행...
        }

        // 예시: PCNG 처리
        private void HandlePCNG(string rawData)
        {
            AddLog("[PCNG] Handling: " + rawData);
            // 실제 로직...
        }
        private async Task HandlePCN2(string rawData, NetworkStream ns)
        {
            AddLog("[PCN2] Handling: " + rawData);

            // TCN2 전문 생성 (위 BuildTCN2Message 함수 사용)
            byte[] tcn2Bytes = BuildTCN2Message();

            // 전송
            await ns.WriteAsync(tcn2Bytes, 0, tcn2Bytes.Length);
            AddLog("[PCN2] Sent TCN2 response: " + Encoding.ASCII.GetString(tcn2Bytes));
        }


        private void StopGatewayCommandListener()
        {
            try
            {
                _commandListenerCts?.Cancel();
                _commandListenerCts = null;
                _commandListener?.Stop();
                _commandListener = null;
                AddLog("Gateway Command Listener stopped.");
            }
            catch (Exception ex)
            {
                AddLog("Error stopping Gateway Command Listener: " + ex.Message);
            }
        }
        #endregion

        public static void AddLog(string message)
        {
            Application.Current.Dispatcher.Invoke(() =>
            {
                var mainWindow = (MainWindow)Application.Current.MainWindow;
                mainWindow.listLogs.Items.Add($"[{DateTime.Now:HH:mm:ss}] {message}");
                mainWindow.listLogs.ScrollIntoView(mainWindow.listLogs.Items[mainWindow.listLogs.Items.Count - 1]);
            });
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            DisconnectFromArduino();
            DisconnectFromServerGateway();
            StopGatewayCommandListener();
        }

        /// <summary>
        /// CRC16 CCITT 계산 (초기값 0xFFFF, 다항식 0x1021, 최종 XOR 없음)
        /// </summary>
        public static ushort ComputeCrc16UsingTable(byte[] data, int offset, int length)
        {
            ushort crc = 0xFFFF;  // 초기값 0xFFFF 설정 (CCITT 표준)

            for (int i = 0; i < length; i++)
            {
                byte index = (byte)((crc >> 8) ^ data[offset + i]); // 상위 8비트와 XOR 연산
                crc = (ushort)((crc << 8) ^ CRC_TABLE[index]);      // 테이블 값과 XOR하여 CRC 갱신
            }
            return crc;
        }

        public static ushort[] MakeCrcTable()
        {
            ushort[] crcTable = new ushort[256];
            const ushort poly = 0x1021;  // x^16 + x^12 + x^5 + 1

            for (int i = 0; i < 256; i++)
            {
                ushort crc = (ushort)(i << 8);
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x8000) != 0)
                        crc = (ushort)((crc << 1) ^ poly);
                    else
                        crc <<= 1;
                }
                crcTable[i] = crc;
            }

            return crcTable;
        }

        public static byte[] BuildTCN2Message()
        {
            // 1) 각 필드 정의 (프로토콜 규격에 맞게 정렬 및 패딩 적용)
            string command = "TCN2";               // 4 bytes
            string bizCode = "4100535";            // 7 bytes
            string stackCode = "001";              // 3 bytes
            string lengthField = "0000";           // 4 bytes (나중에 채움)

            // 바디 (프로토콜 규칙 적용)
            string commServerIp = "192.168.100.3".PadLeft(15) + " ";  // 16 bytes (오른쪽 정렬 후 공백 패딩)
            string gwIp = "192.168.100.170".PadLeft(15) + " ";        // 16 bytes (오른쪽 정렬 후 공백 패딩)
            string makerCode = "MA";                                  // 2 bytes
            string gwModel = "GWModel2023".PadRight(20);              // 20 bytes
            string fwVersion = "FW1.2.3.4".PadRight(20);              // 20 bytes
            string hashCode = "0123456789ABCDEF0123456789ABCDEF";     // 32 bytes
            string password = "1234567890".PadLeft(10);               // 10 bytes (오른쪽 정렬, 공백 패딩)
            string xmissionTime = "9999";                             // 4 bytes
            string dataMode = "0";                                    // 1 byte
            string runWaitTime = "030".PadLeft(3);                    // 3 bytes (오른쪽 정렬, 공백 패딩)
            string stopWaitTime = "030".PadLeft(3);                   // 3 bytes (오른쪽 정렬, 공백 패딩)
            string itemCount = "02";                                  // 2 bytes

            // 항목 (각 24 bytes * 2)
            string item1 = "E0101A000010000050000020";
            string item2 = "F0001D000005000030000015";

            // CRC 필드 (2바이트 바이너리, 초기값 0x0000)
            byte[] crcPlaceholder = new byte[2];

            // 2) 모든 필드를 순서대로 이어붙임 (길이 및 CRC는 임시값)
            string messageWithoutCrc =
                  command
                + bizCode
                + stackCode
                + lengthField
                + commServerIp
                + gwIp
                + makerCode
                + gwModel
                + fwVersion
                + hashCode
                + password
                + xmissionTime
                + dataMode
                + runWaitTime
                + stopWaitTime
                + itemCount
                + item1
                + item2;

            // 3) 전체 메시지를 바이트 배열로 변환 (ASCII)
            byte[] tempBytes = Encoding.ASCII.GetBytes(messageWithoutCrc);

            // 4) 길이 계산 (CRC 포함한 총 메시지 길이 계산)
            int computedLength = tempBytes.Length + 2; // CRC(2바이트) 포함
            string lengthStr = computedLength.ToString("D4"); // 4자리 ASCII 변환

            // 길이 필드를 ASCII 변환하여 삽입 (command + bizCode + stackCode = 14바이트, 길이 필드는 14~17)
            byte[] lengthBytes = Encoding.ASCII.GetBytes(lengthStr);
            Array.Copy(lengthBytes, 0, tempBytes, 14, 4);

            // 5) CRC 계산: 마지막 2바이트(CRC 필드) 제외한 전체 데이터를 대상으로 함
            int crcTargetLen = tempBytes.Length;
            ushort crcValue = ComputeCrc16UsingTable(tempBytes, 0, crcTargetLen);

            // ✅ CRC 값을 로그창(listLogs)에 출력
            AddLog($"[DEBUG] Calculated CRC16: 0x{crcValue:X4}");

            // 6) CRC를 2바이트로 변환 (Big-Endian 방식 적용)
            byte[] crcBytes = BitConverter.GetBytes(crcValue);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(crcBytes); // Big-Endian으로 변환
            }

            // 7) 최종 메시지 구성 (기존 메시지 + CRC)
            byte[] finalMessage = new byte[tempBytes.Length + 2];
            Array.Copy(tempBytes, finalMessage, tempBytes.Length);
            Array.Copy(crcBytes, 0, finalMessage, tempBytes.Length, 2);

            return finalMessage;
        }
    }
}
