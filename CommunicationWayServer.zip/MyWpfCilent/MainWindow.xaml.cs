﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace ServerApp
{
    public partial class MainWindow : Window
    {
        private TcpListener listener;
        private TcpClient client;
        private NetworkStream stream;

        public MainWindow()
        {
            InitializeComponent();
            StartServer();
        }

        private void StartServer()
        {
            listener = new TcpListener(IPAddress.Any, 5000);
            listener.Start();
            AppendMessage("Server started on port 5000.");

            Thread listenerThread = new Thread(() =>
            {
                while (true)
                {
                    try
                    {
                        client = listener.AcceptTcpClient(); // 클라이언트 연결 대기
                        AppendMessage("Client connected!");
                        stream = client.GetStream();

                        // 클라이언트와 데이터를 주고받는 별도 스레드 실행
                        Thread clientThread = new Thread(HandleClient);
                        clientThread.Start();
                    }
                    catch (Exception ex)
                    {
                        AppendMessage($"Error accepting client: {ex.Message}");
                    }
                }
            });

            listenerThread.IsBackground = true;
            listenerThread.Start();
        }

        private void HandleClient()
        {
            try
            {
                byte[] buffer = new byte[1024];
                while (true)
                {
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break; // 클라이언트 연결 종료

                    string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Dispatcher.Invoke(() => AppendMessage($"Client: {receivedMessage}"));
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() => AppendMessage($"Client error: {ex.Message}"));
            }
            finally
            {
                client?.Close();
                AppendMessage("Client disconnected.");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (stream != null)
            {
                string message = SendTextBox.Text;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length); // 클라이언트로 메시지 전송
                AppendMessage($"Server: {message}");
                SendTextBox.Clear();
            }
        }

        private void AppendMessage(string message)
        {
            if (Dispatcher.CheckAccess()) // 현재 스레드가 UI 스레드인지 확인
            {
                // UI 스레드에서 작업 수행
                MessageBox.Text += $"{message}\n";
            }
            else
            {
                // UI 스레드가 아니라면 Dispatcher를 통해 작업 전달
                Dispatcher.Invoke(() => MessageBox.Text += $"{message}\n");
            }
        }
    }
}
