﻿using System;
using System.IO.Ports;

class Program
{
    static void Main()
    {
        // COM 포트와 보드레이트 설정 (COM 포트는 실제 아두이노 포트로 변경 필요)
        SerialPort serialPort = new SerialPort("COM6", 9600);

        try
        {
            serialPort.Open(); // 포트 열기
            Console.WriteLine("아두이노와 연결되었습니다!");

            // 데이터 전송
            string messageToSend = "Hello from C#!";
            serialPort.WriteLine(messageToSend); // 데이터를 아두이노로 전송
            Console.WriteLine("보낸 메시지: " + messageToSend);

            // 아두이노의 응답 읽기
            string arduinoResponse = serialPort.ReadLine(); // 첫 번째 응답 읽기
            Console.WriteLine("아두이노 응답: " + arduinoResponse);

            arduinoResponse = serialPort.ReadLine(); // 두 번째 응답 읽기
            Console.WriteLine("아두이노 응답: " + arduinoResponse);

            serialPort.Close(); // 포트 닫기
        }
        catch (Exception ex)
        {
            Console.WriteLine("오류 발생: " + ex.Message);
        }
    }
}
