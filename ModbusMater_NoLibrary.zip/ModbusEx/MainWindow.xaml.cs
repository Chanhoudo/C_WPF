﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Text;
using System.Windows;

namespace ModbusApp
{
    public partial class MainWindow : Window
    {
        private TcpClient _tcpClient;
        private NetworkStream _stream;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string ipAddress = IpAddressTextBox.Text;
                int port = int.Parse(PortTextBox.Text);

                _tcpClient = new TcpClient(ipAddress, port);
                _stream = _tcpClient.GetStream();

                MessageBox.Show("Connected to Modbus Server!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Connection failed: {ex.Message}");
            }
        }

        private void ReadCoilsButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                byte[] request = CreateReadRequest(1, 0, 10, 0x01); // Function Code 0x01 (Read Coils)
                _stream.Write(request, 0, request.Length);

                byte[] response = new byte[256];
                _stream.Read(response, 0, response.Length);

                List<CoilData> coils = ParseCoilResponse(response, 10);
                CoilGrid.ItemsSource = coils;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading coils: {ex.Message}");
            }
        }

        private void ReadRegistersButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                byte[] request = CreateReadRequest(1, 0, 10, 0x03); // Function Code 0x03 (Read Holding Registers)
                _stream.Write(request, 0, request.Length);

                byte[] response = new byte[256];
                _stream.Read(response, 0, response.Length);

                List<RegisterData> registers = ParseRegisterResponse(response, 10);
                RegisterGrid.ItemsSource = registers;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading registers: {ex.Message}");
            }
        }

        private byte[] CreateReadRequest(byte unitId, ushort startAddress, ushort quantity, byte functionCode)
        {
            byte[] request = new byte[12];
            request[0] = 0; // Transaction ID
            request[1] = 0; // Transaction ID
            request[2] = 0; // Protocol ID
            request[3] = 0; // Protocol ID
            request[4] = 0; // Length
            request[5] = 6; // Length
            request[6] = unitId; // Unit ID
            request[7] = functionCode; // Function Code
            request[8] = (byte)(startAddress >> 8); // Start Address High
            request[9] = (byte)(startAddress & 0xFF); // Start Address Low
            request[10] = (byte)(quantity >> 8); // Quantity High
            request[11] = (byte)(quantity & 0xFF); // Quantity Low
            return request;
        }

        private List<CoilData> ParseCoilResponse(byte[] response, int quantity)
        {
            List<CoilData> coils = new List<CoilData>();
            for (int i = 0; i < quantity; i++)
            {
                bool value = (response[9 + (i / 8)] & (1 << (i % 8))) != 0;
                coils.Add(new CoilData { Address = i, Value = value });
            }
            return coils;
        }

        private List<RegisterData> ParseRegisterResponse(byte[] response, int quantity)
        {
            List<RegisterData> registers = new List<RegisterData>();
            for (int i = 0; i < quantity; i++)
            {
                ushort value = (ushort)((response[9 + i * 2] << 8) | response[9 + i * 2 + 1]);
                registers.Add(new RegisterData { Address = i, Value = value });
            }
            return registers;
        }
    }

    public class CoilData
    {
        public int Address { get; set; }
        public bool Value { get; set; }
    }

    public class RegisterData
    {
        public int Address { get; set; }
        public ushort Value { get; set; }
    }
}
