﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace ClientApp
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private NetworkStream stream;

        public MainWindow()
        {
            InitializeComponent();
            ConnectToServer();
        }

        private void ConnectToServer()
        {
            try
            {
                client = new TcpClient("127.0.0.1", 5000);
                stream = client.GetStream();
                AppendMessage("Connected to server.");

                Thread listenerThread = new Thread(() =>
                {
                    while (true)
                    {
                        try
                        {
                            byte[] buffer = new byte[1024];
                            int bytesRead = stream.Read(buffer, 0, buffer.Length);
                            string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            Dispatcher.Invoke(() => AppendMessage($"Server: {receivedMessage}"));
                        }
                        catch (Exception ex)
                        {
                            Dispatcher.Invoke(() => AppendMessage($"Error: {ex.Message}"));
                            break;
                        }
                    }
                });
                listenerThread.IsBackground = true;
                listenerThread.Start();
            }
            catch (Exception ex)
            {
                AppendMessage($"Connection failed: {ex.Message}");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (stream != null)
            {
                string message = SendTextBox.Text;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length);
                AppendMessage($"Client: {message}");
                SendTextBox.Clear();
            }
        }

        private void AppendMessage(string message)
        {
            MessageBox.Text += $"{message}\n";
        }
    }
}
