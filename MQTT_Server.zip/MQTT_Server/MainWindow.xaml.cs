﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MQTTServer
{
    public partial class MainWindow : Window
    {
        private TcpListener? _tcpListener; // 서버
        private TcpClient? _tcpClient;    // 클라이언트

        public MainWindow()
        {
            InitializeComponent();
        }

        // 서버 시작 버튼 클릭 이벤트
        private async void StartServerButton_Click(object sender, RoutedEventArgs e)
        {
            _tcpListener = new TcpListener(IPAddress.Any, 5000);
            _tcpListener.Start();
            ServerLog.AppendText("Server started...\n");

            await Task.Run(async () =>
            {
                while (true)
                {
                    var client = await _tcpListener.AcceptTcpClientAsync();
                    Dispatcher.Invoke(() => ServerLog.AppendText("Client connected...\n"));
                    _ = Task.Run(() => HandleClient(client));
                }
            });
        }

        private async Task HandleClient(TcpClient client)
        {
            using (var stream = client.GetStream())
            {
                var buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                Dispatcher.Invoke(() => ServerLog.AppendText($"Received: {receivedMessage}\n"));

                // 응답 보내기
                string response = $"Server received: {receivedMessage}";
                byte[] responseBytes = Encoding.UTF8.GetBytes(response);
                await stream.WriteAsync(responseBytes, 0, responseBytes.Length);
            }
        }

        // 클라이언트 연결 버튼 클릭 이벤트
        private async void ConnectClientButton_Click(object sender, RoutedEventArgs e)
        {
            _tcpClient = new TcpClient();
            try
            {
                await _tcpClient.ConnectAsync("127.0.0.1", 5000);
                ClientLog.AppendText("Connected to server...\n");
            }
            catch (Exception ex)
            {
                ClientLog.AppendText($"Error: {ex.Message}\n");
            }
        }



        // 클라이언트 메시지 전송 버튼 클릭 이벤트
        private async void SendMessageButton_Click(object sender, RoutedEventArgs e)
        {
            if (_tcpClient == null || !_tcpClient.Connected)
            {
                ClientLog.AppendText("Not connected to server.\n");
                return;
            }

            try
            {
                var message = ClientMessage.Text;
                var stream = _tcpClient.GetStream();
                byte[] messageBytes = Encoding.UTF8.GetBytes(message);

                await stream.WriteAsync(messageBytes, 0, messageBytes.Length);
                ClientLog.AppendText($"Sent: {message}\n");

                // 서버의 응답 수신
                var buffer = new byte[1024];
                int bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                string response = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                ClientLog.AppendText($"Received: {response}\n");
            }
            catch (Exception ex)
            {
                ClientLog.AppendText($"Error: {ex.Message}\n");
            }
        }
    }
}
