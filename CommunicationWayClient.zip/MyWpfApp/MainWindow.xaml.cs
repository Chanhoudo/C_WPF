﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows;

namespace ClientApp
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private NetworkStream stream;

        public MainWindow()
        {
            InitializeComponent();
            ConnectToServer();
        }

        private void ConnectToServer()
        {
            try
            {
                client = new TcpClient("127.0.0.1", 5000); // 서버에 연결
                AppendMessage("Connected to server.");
                stream = client.GetStream();

                // 서버로부터 메시지를 수신하는 별도 스레드 실행
                Thread listenerThread = new Thread(ReceiveMessages);
                listenerThread.IsBackground = true;
                listenerThread.Start();
            }
            catch (Exception ex)
            {
                AppendMessage($"Connection failed: {ex.Message}");
            }
        }

        private void ReceiveMessages()
        {
            try
            {
                byte[] buffer = new byte[1024];
                while (true)
                {
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break; // 서버 연결 종료

                    string receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                    Dispatcher.Invoke(() => AppendMessage($"Server: {receivedMessage}"));
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() => AppendMessage($"Error receiving message: {ex.Message}"));
            }
            finally
            {
                client?.Close();
                AppendMessage("Disconnected from server.");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            if (stream != null)
            {
                string message = SendTextBox.Text;
                byte[] data = Encoding.UTF8.GetBytes(message);
                stream.Write(data, 0, data.Length); // 서버로 메시지 전송
                AppendMessage($"Client: {message}");
                SendTextBox.Clear();
            }
        }

        private void AppendMessage(string message)
        {
            if (Dispatcher.CheckAccess()) // 현재 스레드가 UI 스레드인지 확인
            {
                // UI 스레드에서 작업 수행
                MessageBox.Text += $"{message}\n";
            }
            else
            {
                // UI 스레드가 아니라면 Dispatcher를 통해 작업 전달
                Dispatcher.Invoke(() => MessageBox.Text += $"{message}\n");
            }
        }
    }
}
