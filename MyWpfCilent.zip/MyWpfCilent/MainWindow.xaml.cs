﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Windows;

namespace SenderApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string message = InputTextBox.Text;

            try
            {
                using (TcpClient client = new TcpClient("127.0.0.1", 5000))
                {
                    NetworkStream stream = client.GetStream();
                    byte[] data = Encoding.UTF8.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                    MessageBox.Show("Message Sent!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
    }
}
