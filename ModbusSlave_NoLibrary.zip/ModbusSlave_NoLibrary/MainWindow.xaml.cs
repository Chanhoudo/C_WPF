﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Windows;

namespace ModbusSlaveApp
{
    public partial class MainWindow : Window
    {
        private TcpListener _listener;
        private Thread _serverThread;
        private bool _isRunning = false;
        private ushort[] _holdingRegisters = new ushort[10]; // 10개의 Holding Register

        public MainWindow()
        {
            InitializeComponent();
            InitializeRegisters();
        }

        private void InitializeRegisters()
        {
            // 초기값 설정
            for (int i = 0; i < _holdingRegisters.Length; i++)
            {
                _holdingRegisters[i] = (ushort)(i * 10); // 예: 0, 10, 20, ...
            }

            // UI 업데이트
            RegisterGrid.ItemsSource = GetRegisterData();
        }

        private List<RegisterData> GetRegisterData()
        {
            var data = new List<RegisterData>();
            for (int i = 0; i < _holdingRegisters.Length; i++)
            {
                data.Add(new RegisterData { Address = i, Value = _holdingRegisters[i] });
            }
            return data;
        }

        private void StartServerButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isRunning) return;

            int port = int.Parse(PortTextBox.Text);
            _listener = new TcpListener(IPAddress.Any, port);
            _listener.Start();

            _isRunning = true;
            _serverThread = new Thread(RunServer) { IsBackground = true };
            _serverThread.Start();

            MessageBox.Show("Modbus Slave Server Started.");
        }

        private void RunServer()
        {
            try
            {
                while (_isRunning)
                {
                    TcpClient client = _listener.AcceptTcpClient();
                    NetworkStream stream = client.GetStream();

                    while (client.Connected)
                    {
                        if (stream.DataAvailable)
                        {
                            byte[] request = new byte[12];
                            stream.Read(request, 0, request.Length);
                            byte[] response = HandleRequest(request);
                            stream.Write(response, 0, response.Length);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() => MessageBox.Show($"Error: {ex.Message}"));
            }
        }

        private byte[] HandleRequest(byte[] request)
        {
            // 요청 파싱
            byte unitId = request[6];
            byte functionCode = request[7];
            ushort startAddress = (ushort)((request[8] << 8) | request[9]);
            ushort quantity = (ushort)((request[10] << 8) | request[11]);

            // 응답 생성
            byte[] response;

            if (functionCode == 0x03) // Read Holding Registers
            {
                response = CreateReadResponse(unitId, startAddress, quantity);
            }
            else
            {
                // Unsupported Function Code
                response = CreateErrorResponse(unitId, functionCode, 0x01);
            }

            return response;
        }

        private byte[] CreateReadResponse(byte unitId, ushort startAddress, ushort quantity)
        {
            byte[] response = new byte[9 + quantity * 2];
            response[0] = 0; // Transaction ID
            response[1] = 0; // Transaction ID
            response[2] = 0; // Protocol ID
            response[3] = 0; // Protocol ID
            response[4] = 0; // Length
            response[5] = (byte)(3 + quantity * 2); // Length
            response[6] = unitId; // Unit ID
            response[7] = 0x03; // Function Code
            response[8] = (byte)(quantity * 2); // Byte Count

            for (int i = 0; i < quantity; i++)
            {
                ushort value = _holdingRegisters[startAddress + i];
                response[9 + i * 2] = (byte)(value >> 8); // High Byte
                response[10 + i * 2] = (byte)(value & 0xFF); // Low Byte
            }

            return response;
        }

        private byte[] CreateErrorResponse(byte unitId, byte functionCode, byte errorCode)
        {
            byte[] response = new byte[9];
            response[0] = 0; // Transaction ID
            response[1] = 0; // Transaction ID
            response[2] = 0; // Protocol ID
            response[3] = 0; // Protocol ID
            response[4] = 0; // Length
            response[5] = 3; // Length
            response[6] = unitId; // Unit ID
            response[7] = (byte)(functionCode | 0x80); // Error Function Code
            response[8] = errorCode; // Error Code
            return response;
        }
    }

    public class RegisterData
    {
        public int Address { get; set; }
        public ushort Value { get; set; }
    }
}
