﻿using System;
using System.IO.Ports;
using System.Windows;
using System.Windows.Controls;

namespace PicoSetting
{
    public partial class MainWindow : Window
    {
        private DataDisplayWindow displayWindow;
        private SerialPort serialPort = new SerialPort();

        public MainWindow()
        {
            InitializeComponent();
            LoadAvailablePorts();
            BaudRateComboBox.SelectedIndex = 0; // 기본 baud rate 선택 (예: 9600)
            // Serial 데이터 수신 이벤트 핸들러 등록
            serialPort.DataReceived += SerialPort_DataReceived;
        }

        // 현재 연결 가능한 COM Port 목록 불러오기
        private void LoadAvailablePorts()
        {
            ComPortComboBox.Items.Clear();
            foreach (string port in SerialPort.GetPortNames())
            {
                ComPortComboBox.Items.Add(port);
            }
            if (ComPortComboBox.Items.Count > 0)
            {
                ComPortComboBox.SelectedIndex = 0;
            }
        }

        // COM Reset 버튼 클릭: 포트 목록 새로고침
        private void ComReset_Click(object sender, RoutedEventArgs e)
        {
            LoadAvailablePorts();
        }

        // Open 버튼 클릭: 시리얼 포트 열기
        private void OpenButton_Click(object sender, RoutedEventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                try
                {
                    serialPort.PortName = ComPortComboBox.SelectedItem.ToString();

                    if (BaudRateComboBox.SelectedItem is ComboBoxItem selectedBaud)
                    {
                        serialPort.BaudRate = Convert.ToInt32(selectedBaud.Content);
                    }
                    else
                    {
                        serialPort.BaudRate = 9600;
                    }

                    serialPort.Open();
                    StatusTextBlock.Text = "Serial Port 상태: Open";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Serial Port 열기 오류: " + ex.Message);
                }
            }
        }

        // Close 버튼 클릭: 시리얼 포트 닫기
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                try
                {
                    serialPort.Close();
                    StatusTextBlock.Text = "Serial Port 상태: Close";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Serial Port 닫기 오류: " + ex.Message);
                }
            }
        }

        // Write 버튼 클릭: 입력 데이터를 Arduino로 전송(EEPROM 저장 명령)
        private void WriteButton_Click(object sender, RoutedEventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                MessageBox.Show("먼저 Serial Port를 열어주세요.");
                return;
            }

            // 각 텍스트박스의 값을 조합하여 하나의 문자열 생성
            // MAC 주소는 하이픈(-), IP 등은 점(.) 구분자로 연결
            string picoMac = $"{PicoMac1.Text}-{PicoMac2.Text}-{PicoMac3.Text}-{PicoMac4.Text}-{PicoMac5.Text}-{PicoMac6.Text}";
            string picoIp = $"{Pico_Ip1.Text}.{Pico_Ip2.Text}.{Pico_Ip3.Text}.{Pico_Ip4.Text}";
            string subnet = $"{Subnet1.Text}.{Subnet2.Text}.{Subnet3.Text}.{Subnet4.Text}";
            string gateway = $"{Gateway1.Text}.{Gateway2.Text}.{Gateway3.Text}.{Gateway4.Text}";
            string dns = $"{DNS1.Text}.{DNS2.Text}.{DNS3.Text}.{DNS4.Text}";
            string serverIp = $"{PICO_Server_IP1.Text}.{PICO_Server_IP2.Text}.{PICO_Server_IP3.Text}.{PICO_Server_IP4.Text}";
            string tcpUdp = (TcpRadioButton.IsChecked == true) ? "TCP" : "UDP";
            string port = PortTextBox.Text;
            string info485 = Info485TextBox.Text;

            // 프로토콜 예시: "W|picoMac|picoIp|subnet|gateway|dns|serverIp|tcpUdp|port|info485"
            string command = $"W|{picoMac}|{picoIp}|{subnet}|{gateway}|{dns}|{serverIp}|{tcpUdp}|{port}|{info485}\n";

            try
            {
                serialPort.WriteLine(command);
                StatusTextBlock.Text = "데이터 쓰기 명령 전송 완료.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 전송 중 오류: " + ex.Message);
            }
        }

        // Read 버튼 클릭: EEPROM에 저장된 데이터를 읽어오도록 Arduino에 명령 전송
        private void ReadButton_Click(object sender, RoutedEventArgs e)
        {
            if (!serialPort.IsOpen)
            {
                MessageBox.Show("먼저 Serial Port를 열어주세요.");
                return;
            }

            // 1) 창을 띄우고 "로딩 중" 문구로 초기화
            displayWindow = new DataDisplayWindow("EEPROM 데이터 로딩 중...");
            displayWindow.Show();

            // 2) 아두이노에 "R" 명령 전송
            try
            {
                serialPort.WriteLine("R");
                StatusTextBlock.Text = "데이터 읽기 명령 전송 완료.";
            }
            catch (Exception ex)
            {
                MessageBox.Show("데이터 읽기 명령 전송 오류: " + ex.Message);
            }
        }

        // 시리얼 수신 이벤트
        private void SerialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string data = serialPort.ReadLine();
                Dispatcher.Invoke(() => UpdateDataDisplay(data));
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    StatusTextBlock.Text = "수신 오류: " + ex.Message;
                });
            }
        }

        // 이미 열려 있는 dataDisplayWindow 내부를 갱신
        private void UpdateDataDisplay(string data)
        {
            // 만약 창이 닫혔거나 null이면 새로 열 수도 있음
            if (displayWindow == null || !displayWindow.IsLoaded)
            {
                displayWindow = new DataDisplayWindow("");
                displayWindow.Show();
            }

            // 데이터 파싱
            if (data.StartsWith("R|"))
            {
                string[] parts = data.Split('|');
                if (parts.Length >= 10)
                {
                    // (생략) MAC, IP 세팅 등...

                    string displayData = $"MAC : {parts[1]}\nIP : {parts[2]}\n...";

                    // **기존 창의 TextBlock만 갱신**
                    displayWindow.DataTextBlock.Text = displayData;
                    StatusTextBlock.Text = "EEPROM 데이터 읽기 완료.";
                }
                else
                {
                    displayWindow.DataTextBlock.Text = "수신 데이터 형식 오류.";
                }
            }
            else
            {
                displayWindow.DataTextBlock.Text = "알 수 없는 데이터: " + data;
            }
        }

        // PicoMac1 입력 완료 시 다음 텍스트박스로 포커스 이동 (예시)
        private void PicoMac1_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (PicoMac1.Text.Length == PicoMac1.MaxLength)
            {
                PicoMac2.Focus();
            }
        }


        // Arduino로부터 받은 데이터를 파싱하여 UI 컨트롤에 적용하고, 새 창을 띄워 표시합니다.
        // 예상 데이터 형식: "R|picoMac|picoIp|subnet|gateway|dns|serverIp|tcpUdp|port|info485"
        private void ProcessReceivedData(string data)
        {
            data = data.Trim();
            if (data.StartsWith("R|"))
            {
                string[] parts = data.Split('|');
                if (parts.Length >= 10)
                {
                    // picoMac 처리 (하이픈(-)으로 구분: ex. "255-255-255-255-255-255")
                    string[] macParts = parts[1].Split('-');
                    if (macParts.Length >= 6)
                    {
                        PicoMac1.Text = macParts[0];
                        PicoMac2.Text = macParts[1];
                        PicoMac3.Text = macParts[2];
                        PicoMac4.Text = macParts[3];
                        PicoMac5.Text = macParts[4];
                        PicoMac6.Text = macParts[5];
                    }

                    // picoIp 처리 (점(.) 구분)
                    string[] ipParts = parts[2].Split('.');
                    if (ipParts.Length >= 4)
                    {
                        Pico_Ip1.Text = ipParts[0];
                        Pico_Ip2.Text = ipParts[1];
                        Pico_Ip3.Text = ipParts[2];
                        Pico_Ip4.Text = ipParts[3];
                    }

                    // Subnet 처리
                    string[] subnetParts = parts[3].Split('.');
                    if (subnetParts.Length >= 4)
                    {
                        Subnet1.Text = subnetParts[0];
                        Subnet2.Text = subnetParts[1];
                        Subnet3.Text = subnetParts[2];
                        Subnet4.Text = subnetParts[3];
                    }

                    // Gateway 처리
                    string[] gatewayParts = parts[4].Split('.');
                    if (gatewayParts.Length >= 4)
                    {
                        Gateway1.Text = gatewayParts[0];
                        Gateway2.Text = gatewayParts[1];
                        Gateway3.Text = gatewayParts[2];
                        Gateway4.Text = gatewayParts[3];
                    }

                    // DNS 처리
                    string[] dnsParts = parts[5].Split('.');
                    if (dnsParts.Length >= 4)
                    {
                        DNS1.Text = dnsParts[0];
                        DNS2.Text = dnsParts[1];
                        DNS3.Text = dnsParts[2];
                        DNS4.Text = dnsParts[3];
                    }

                    // Server IP 처리
                    string[] serverIpParts = parts[6].Split('.');
                    if (serverIpParts.Length >= 4)
                    {
                        PICO_Server_IP1.Text = serverIpParts[0];
                        PICO_Server_IP2.Text = serverIpParts[1];
                        PICO_Server_IP3.Text = serverIpParts[2];
                        PICO_Server_IP4.Text = serverIpParts[3];
                    }

                    // TCP/UDP 처리
                    if (parts[7].Trim().ToUpper() == "TCP")
                    {
                        TcpRadioButton.IsChecked = true;
                    }
                    else if (parts[7].Trim().ToUpper() == "UDP")
                    {
                        UdpRadioButton.IsChecked = true;
                    }

                    // Port와 485 정보 처리
                    PortTextBox.Text = parts[8];
                    Info485TextBox.Text = parts[9];

                    StatusTextBlock.Text = "EEPROM 데이터 읽기 완료.";

                    // 읽어온 데이터를 새 창에 표시하기 위한 문자열 구성
                    string displayData = $"PICO_MAC : {parts[1]}\n" +
                                         $"PICO_IP : {parts[2]}\n" +
                                         $"Subnet  : {parts[3]}\n" +
                                         $"Gateway : {parts[4]}\n" +
                                         $"DNS     : {parts[5]}\n" +
                                         $"Server IP : {parts[6]}\n" +
                                         $"TCP/UDP : {parts[7]}\n" +
                                         $"Port    : {parts[8]}\n" +
                                         $"485 정보 : {parts[9]}";

                    // DataDisplayWindow 창을 생성하여 읽은 데이터를 표시
                    DataDisplayWindow displayWindow = new DataDisplayWindow(displayData);
                    displayWindow.Show();
                }
                else
                {
                    StatusTextBlock.Text = "수신 데이터 형식 오류.";
                }
            }
            else
            {
                StatusTextBlock.Text = "알 수 없는 데이터 수신: " + data;
            }
        }
    }
}
