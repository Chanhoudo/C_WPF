﻿using System.Windows;

namespace PicoSetting
{
    public partial class DataDisplayWindow : Window
    {
        // 생성자에 표시할 데이터를 문자열로 전달받음
        public DataDisplayWindow(string data)
        {
            InitializeComponent();
            DataTextBlock.Text = data;
        }
    }
}
